var _u_p_r_i_s_e___e_n_g_i_n_e___d_e_b_u_g_2framework_8h =
[
    [ "WIN32_LEAN_AND_MEAN", "_u_p_r_i_s_e___e_n_g_i_n_e___d_e_b_u_g_2framework_8h.html#ac7bef5d85e3dcd73eef56ad39ffc84a9", null ]
];